package com.oreilly.demo;

public class PrintService {

	public void print(String message){
		System.out.println(message);
	}
}
