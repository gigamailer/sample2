package com.oreilly.demo;

public interface CustomGateway {

	public void print(String message);
	
}
