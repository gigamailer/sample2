package com.oreilly.integration;

public class CustomHeaderEnricher {

	public String getHeaderValue(){
		return "This is the header value";
	}
}
